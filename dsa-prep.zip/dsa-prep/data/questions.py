TOPICS = [
    {
        "slug": "arrays-hashing",
        "title": "Arrays & Hashing",
        "color": "#00D9FF",
        "icon": "⚡",
        "total": 12,
        "questions": [
            {
                "id": 1,
                "leetcode_number": 1,
                "title": "Two Sum",
                "difficulty": "Easy",
                "url": "https://leetcode.com/problems/two-sum/",
                "problem_statement": "Given an array of integers <code>nums</code> and an integer <code>target</code>, return indices of the two numbers such that they add up to target. You may assume that each input would have exactly one solution, and you may not use the same element twice.",
                "examples": [
                    {
                        "input": "nums = [2,7,11,15], target = 9",
                        "output": "[0,1]",
                        "explanation": "Because nums[0] + nums[1] == 9, we return [0, 1]."
                    },
                    {
                        "input": "nums = [3,2,4], target = 6",
                        "output": "[1,2]",
                        "explanation": ""
                    },
                    {
                        "input": "nums = [3,3], target = 6",
                        "output": "[0,1]",
                        "explanation": ""
                    }
                ],
                "constraints": [
                    "2 ≤ nums.length ≤ 10⁴",
                    "-10⁹ ≤ nums[i] ≤ 10⁹",
                    "-10⁹ ≤ target ≤ 10⁹",
                    "Only one valid answer exists."
                ],
                "intuition": "For each number, we need to find if its complement (target - num) exists in the array. The naive way checks every pair — but we can do better by trading space for time using a HashMap that remembers what we've seen.",
                "approaches": [
                    {
                        "name": "Brute Force",
                        "badge": "O(n²)",
                        "badge_color": "red",
                        "description": "Check every pair of numbers. For each element i, scan all j > i and check if nums[i] + nums[j] == target.",
                        "time": "O(n²)",
                        "space": "O(1)",
                        "why_not": "Too slow for large inputs. Two nested loops = quadratic time.",
                        "code": None
                    },
                    {
                        "name": "HashMap (One Pass)",
                        "badge": "Optimal",
                        "badge_color": "green",
                        "description": "As we iterate, store each number and its index in a HashMap. For each element, check if <code>target - nums[i]</code> already exists in the map. If yes — found! If no — add current element to map and continue.",
                        "time": "O(n)",
                        "space": "O(n)",
                        "why_not": None,
                        "code": """class Solution {
    public int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) {
                return new int[]{map.get(complement), i};
            }
            map.put(nums[i], i);
        }
        return new int[]{};
    }
}"""
                    }
                ],
                "interview_qa": [
                    {
                        "q": "Why does a HashMap give O(1) lookup?",
                        "a": "HashMaps use a hash function to directly compute a bucket index from the key, making average-case lookup O(1). Collisions can degrade to O(n) but are rare with good hash functions."
                    },
                    {
                        "q": "What if there are duplicate numbers?",
                        "a": "Since we check the map before inserting, we handle duplicates correctly — e.g. [3,3], target=6 works because when we see the second 3, the first 3 is already in the map."
                    },
                    {
                        "q": "Can you solve it with sorted array + two pointers?",
                        "a": "Yes, but sorting loses the original indices. You'd need to store (value, original_index) pairs. Time becomes O(n log n) — worse than the HashMap approach."
                    }
                ]
            },
            {
                "id": 2,
                "leetcode_number": 49,
                "title": "Group Anagrams",
                "difficulty": "Medium",
                "url": "https://leetcode.com/problems/group-anagrams/",
                "problem_statement": "Given an array of strings <code>strs</code>, group the anagrams together. You can return the answer in any order. An anagram is a word or phrase formed by rearranging the letters of another, such as 'anagram' formed from 'nagaram'.",
                "examples": [
                    {
                        "input": 'strs = ["eat","tea","tan","ate","nat","bat"]',
                        "output": '[["bat"],["nat","tan"],["ate","eat","tea"]]',
                        "explanation": ""
                    },
                    {
                        "input": 'strs = [""]',
                        "output": '[[""]]',
                        "explanation": ""
                    },
                    {
                        "input": 'strs = ["a"]',
                        "output": '[["a"]]',
                        "explanation": ""
                    }
                ],
                "constraints": [
                    "1 ≤ strs.length ≤ 10⁴",
                    "0 ≤ strs[i].length ≤ 100",
                    "strs[i] consists of lowercase English letters."
                ],
                "intuition": "Anagrams are words with the same characters — just rearranged. We need a consistent 'signature' (key) for each group. Two natural keys: sorted string (\"eat\" → \"aet\") or character frequency array. All words sharing a key are anagrams.",
                "approaches": [
                    {
                        "name": "Brute Force",
                        "badge": "O(n² · k log k)",
                        "badge_color": "red",
                        "description": "Compare each word with every other word by sorting both and checking equality. Group together if they match.",
                        "time": "O(n² · k log k)",
                        "space": "O(n)",
                        "why_not": "Quadratic comparisons, each with a sort. Way too slow.",
                        "code": None
                    },
                    {
                        "name": "Sort as Key (HashMap)",
                        "badge": "Good",
                        "badge_color": "yellow",
                        "description": "Sort each string to get a canonical key. Use a HashMap from sorted_string → list of original strings. All anagrams share the same sorted key.",
                        "time": "O(n · k log k)",
                        "space": "O(n · k)",
                        "why_not": "Sorting each string takes O(k log k). Good but we can do better.",
                        "code": None
                    },
                    {
                        "name": "Frequency Array as Key (Optimal)",
                        "badge": "Optimal",
                        "badge_color": "green",
                        "description": "Instead of sorting, build a 26-element frequency count array for each word. Convert it to a string/tuple as the HashMap key. This avoids sorting entirely.",
                        "time": "O(n · k)",
                        "space": "O(n · k)",
                        "why_not": None,
                        "code": """class Solution {
    public List<List<String>> groupAnagrams(String[] strs) {
        Map<String, List<String>> map = new HashMap<>();
        for (String s : strs) {
            int[] count = new int[26];
            for (char c : s.toCharArray())
                count[c - 'a']++;
            String key = Arrays.toString(count);
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
        }
        return new ArrayList<>(map.values());
    }
}"""
                    }
                ],
                "interview_qa": [
                    {
                        "q": "Why is the frequency array approach faster than sorting?",
                        "a": "Counting characters is O(k) while sorting is O(k log k). For long strings, this is meaningfully faster."
                    },
                    {
                        "q": "What's the trade-off if strings can contain non-ASCII characters?",
                        "a": "The fixed 26-element array only works for lowercase English letters. For Unicode, you'd use a HashMap<Character, Integer> as your frequency counter, or fall back to sorting."
                    },
                    {
                        "q": "How do you handle empty strings?",
                        "a": "Empty strings all have zero frequency counts → same key → grouped together. The algorithm handles it naturally."
                    }
                ]
            },
            {
                "id": 3,
                "leetcode_number": 217,
                "title": "Contains Duplicate",
                "difficulty": "Easy",
                "url": "https://leetcode.com/problems/contains-duplicate/",
                "problem_statement": "Given an integer array <code>nums</code>, return <code>true</code> if any value appears at least twice in the array, and return <code>false</code> if every element is distinct.",
                "examples": [
                    {
                        "input": "nums = [1,2,3,1]",
                        "output": "true",
                        "explanation": "1 appears at index 0 and 3."
                    },
                    {
                        "input": "nums = [1,2,3,4]",
                        "output": "false",
                        "explanation": ""
                    },
                    {
                        "input": "nums = [1,1,1,3,3,4,3,2,4,2]",
                        "output": "true",
                        "explanation": ""
                    }
                ],
                "constraints": [
                    "1 ≤ nums.length ≤ 10⁵",
                    "-10⁹ ≤ nums[i] ≤ 10⁹"
                ],
                "intuition": "We need to detect if any number repeats. The question is: how do we remember what we've already seen, as efficiently as possible?",
                "approaches": [
                    {
                        "name": "Brute Force",
                        "badge": "O(n²)",
                        "badge_color": "red",
                        "description": "Compare every pair (i, j). If nums[i] == nums[j], return true.",
                        "time": "O(n²)",
                        "space": "O(1)",
                        "why_not": "Too slow. Two nested loops.",
                        "code": None
                    },
                    {
                        "name": "Sorting",
                        "badge": "O(n log n)",
                        "badge_color": "yellow",
                        "description": "Sort the array. Duplicates will be adjacent. Scan once — if nums[i] == nums[i+1], return true.",
                        "time": "O(n log n)",
                        "space": "O(1) or O(n) depending on sort",
                        "why_not": "Modifies the array. Slower than HashSet approach.",
                        "code": None
                    },
                    {
                        "name": "HashSet (Optimal)",
                        "badge": "Optimal",
                        "badge_color": "green",
                        "description": "Use a HashSet to track seen numbers. For each element, if it's already in the set → duplicate found. Else add it to the set.",
                        "time": "O(n)",
                        "space": "O(n)",
                        "why_not": None,
                        "code": """class Solution {
    public boolean containsDuplicate(int[] nums) {
        Set<Integer> seen = new HashSet<>();
        for (int num : nums) {
            if (!seen.add(num)) {  // add() returns false if already present
                return true;
            }
        }
        return false;
    }
}"""
                    }
                ],
                "interview_qa": [
                    {
                        "q": "Why use HashSet over HashMap here?",
                        "a": "We only care about existence (seen or not), not counts or indices. HashSet is simpler and uses slightly less memory than HashMap."
                    },
                    {
                        "q": "What if the constraint was O(1) extra space?",
                        "a": "You'd sort the array in-place (O(n log n)) and check adjacent elements. This trades time for space."
                    },
                    {
                        "q": "Can you do it in one line in Java?",
                        "a": "Yes: return nums.length != Arrays.stream(nums).distinct().count(); — but less efficient due to boxing/unboxing."
                    }
                ]
            },
            {
                "id": 4,
                "leetcode_number": 238,
                "title": "Product of Array Except Self",
                "difficulty": "Medium",
                "url": "https://leetcode.com/problems/product-of-array-except-self/",
                "problem_statement": "Given an integer array <code>nums</code>, return an array <code>answer</code> such that <code>answer[i]</code> is equal to the product of all the elements of nums except <code>nums[i]</code>. The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer. You must write an algorithm that runs in O(n) time and without using the division operation.",
                "examples": [
                    {
                        "input": "nums = [1,2,3,4]",
                        "output": "[24,12,8,6]",
                        "explanation": ""
                    },
                    {
                        "input": "nums = [-1,1,0,-3,3]",
                        "output": "[0,0,9,0,0]",
                        "explanation": ""
                    }
                ],
                "constraints": [
                    "2 ≤ nums.length ≤ 10⁵",
                    "-30 ≤ nums[i] ≤ 30",
                    "The product of any prefix or suffix fits in 32-bit integer.",
                    "Must be O(n) without division."
                ],
                "intuition": "For each index i, the answer is: (product of all elements LEFT of i) × (product of all elements RIGHT of i). We can precompute both passes independently, then multiply them.",
                "approaches": [
                    {
                        "name": "Brute Force",
                        "badge": "O(n²)",
                        "badge_color": "red",
                        "description": "For each index i, multiply all elements except nums[i]. Two nested loops.",
                        "time": "O(n²)",
                        "space": "O(1)",
                        "why_not": "Too slow. And the problem explicitly forbids naive approaches.",
                        "code": None
                    },
                    {
                        "name": "Division Trick",
                        "badge": "O(n) — Not Allowed",
                        "badge_color": "orange",
                        "description": "Compute total product, then divide by nums[i] for each index. But division is explicitly forbidden, and breaks on zeros.",
                        "time": "O(n)",
                        "space": "O(1)",
                        "why_not": "Problem says no division. Fails when nums[i] = 0.",
                        "code": None
                    },
                    {
                        "name": "Prefix × Suffix Arrays",
                        "badge": "O(n) Space",
                        "badge_color": "yellow",
                        "description": "Build leftProduct[i] = product of nums[0..i-1] and rightProduct[i] = product of nums[i+1..n-1]. Answer[i] = leftProduct[i] × rightProduct[i].",
                        "time": "O(n)",
                        "space": "O(n)",
                        "why_not": "Works great — the O(1) space variant below is just more elegant.",
                        "code": None
                    },
                    {
                        "name": "Prefix Pass + Running Right (Optimal)",
                        "badge": "Optimal",
                        "badge_color": "green",
                        "description": "Use only the output array. First pass: fill answer[i] with left products. Second pass: traverse right-to-left with a running right product multiplier, updating answer[i] in place.",
                        "time": "O(n)",
                        "space": "O(1) extra (output array doesn't count)",
                        "why_not": None,
                        "code": """class Solution {
    public int[] productExceptSelf(int[] nums) {
        int n = nums.length;
        int[] answer = new int[n];
        
        // First pass: fill with left products
        answer[0] = 1;
        for (int i = 1; i < n; i++) {
            answer[i] = answer[i - 1] * nums[i - 1];
        }
        
        // Second pass: multiply by right products (running)
        int rightProduct = 1;
        for (int i = n - 1; i >= 0; i--) {
            answer[i] *= rightProduct;
            rightProduct *= nums[i];
        }
        
        return answer;
    }
}"""
                    }
                ],
                "interview_qa": [
                    {
                        "q": "Why doesn't the division trick work?",
                        "a": "Two reasons: the problem explicitly forbids it, and it breaks when nums contains zeros — you can't divide by zero."
                    },
                    {
                        "q": "What if there are multiple zeros in the array?",
                        "a": "If there are 2+ zeros, every answer[i] = 0 because any product will include at least one zero. The prefix/suffix approach handles this naturally."
                    },
                    {
                        "q": "Why is the output array not counted in space complexity?",
                        "a": "By convention, the output array is required to return the answer — it's not auxiliary space. Only extra space used by your algorithm counts."
                    }
                ]
            },
            {
                "id": 5,
                "leetcode_number": 53,
                "title": "Maximum Subarray",
                "difficulty": "Medium",
                "url": "https://leetcode.com/problems/maximum-subarray/",
                "problem_statement": "Given an integer array <code>nums</code>, find the subarray with the largest sum, and return its sum. A subarray is a contiguous part of an array.",
                "examples": [
                    {
                        "input": "nums = [-2,1,-3,4,-1,2,1,-5,4]",
                        "output": "6",
                        "explanation": "The subarray [4,-1,2,1] has the largest sum = 6."
                    },
                    {
                        "input": "nums = [1]",
                        "output": "1",
                        "explanation": ""
                    },
                    {
                        "input": "nums = [5,4,-1,7,8]",
                        "output": "23",
                        "explanation": ""
                    }
                ],
                "constraints": [
                    "1 ≤ nums.length ≤ 10⁵",
                    "-10⁴ ≤ nums[i] ≤ 10⁴"
                ],
                "intuition": "At each position, we make a greedy choice: should we extend the current subarray, or start fresh? If the current running sum becomes negative, it only drags down future sums — so we reset it to 0. This is Kadane's Algorithm.",
                "approaches": [
                    {
                        "name": "Brute Force",
                        "badge": "O(n²) or O(n³)",
                        "badge_color": "red",
                        "description": "Try all possible subarrays (i to j), compute their sum, track the maximum. O(n³) naively; O(n²) if you compute running sums.",
                        "time": "O(n²)",
                        "space": "O(1)",
                        "why_not": "Too slow for n = 10⁵.",
                        "code": None
                    },
                    {
                        "name": "Divide & Conquer",
                        "badge": "O(n log n)",
                        "badge_color": "yellow",
                        "description": "Split the array in half. The maximum subarray either lies entirely in the left half, entirely in the right half, or crosses the midpoint. Recurse and merge.",
                        "time": "O(n log n)",
                        "space": "O(log n)",
                        "why_not": "More complex to implement. Kadane's is simpler and faster.",
                        "code": None
                    },
                    {
                        "name": "Kadane's Algorithm (Optimal)",
                        "badge": "Optimal",
                        "badge_color": "green",
                        "description": "Track <code>currentSum</code>: at each step, either extend the current subarray (add nums[i]) or start fresh from nums[i] — whichever is larger. Update <code>maxSum</code> at every step.",
                        "time": "O(n)",
                        "space": "O(1)",
                        "why_not": None,
                        "code": """class Solution {
    public int maxSubArray(int[] nums) {
        int maxSum = nums[0];
        int currentSum = nums[0];
        
        for (int i = 1; i < nums.length; i++) {
            // Either extend current subarray or start fresh
            currentSum = Math.max(nums[i], currentSum + nums[i]);
            maxSum = Math.max(maxSum, currentSum);
        }
        
        return maxSum;
    }
}"""
                    }
                ],
                "interview_qa": [
                    {
                        "q": "Why initialize maxSum and currentSum to nums[0] and not 0?",
                        "a": "Because all numbers could be negative. If we init to 0, we'd wrongly return 0 instead of the least-negative element."
                    },
                    {
                        "q": "Can you return the actual subarray, not just the sum?",
                        "a": "Yes — track start, end, and tempStart indices. When currentSum resets, update tempStart = i. When maxSum updates, set start = tempStart, end = i."
                    },
                    {
                        "q": "How does this relate to dynamic programming?",
                        "a": "Kadane's IS DP — dp[i] = max subarray ending at i = max(nums[i], dp[i-1] + nums[i]). We just optimize space by keeping only the previous value."
                    }
                ]
            }
        ]
    }
]
